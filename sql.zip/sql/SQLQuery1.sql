-- Phần 0: Dọn dẹp môi trường
-- Xóa các bảng nếu chúng đã tồn tại. Việc này giúp chạy lại kịch bản từ đầu.
-- Phải xóa bảng tham chiếu (LichKham, LichTruc) trước bảng được tham chiếu (BacSi).

IF OBJECT_ID('LichTruc', 'U') IS NOT NULL 
    DROP TABLE LichTruc;
GO
IF OBJECT_ID('LichKham', 'U') IS NOT NULL 
    DROP TABLE LichKham;
GO
IF OBJECT_ID('BacSi', 'U') IS NOT NULL 
    DROP TABLE BacSi;
GO

----------------------------------------------------------------------
-- Phần 1: TẠO CÁC BẢNG (DDL)
----------------------------------------------------------------------

-- Bảng 1: BacSi
CREATE TABLE BacSi (
    MaBS CHAR(5) PRIMARY KEY,
    HoTen NVARCHAR(50) NOT NULL,
    GioiTinh NVARCHAR(5),
    DiaChi NVARCHAR(100),
    ChuyenKhoa NVARCHAR(50) NOT NULL
);
GO

-- Bảng 2: LichKham
CREATE TABLE LichKham (
    MaKham INT IDENTITY(1,1) PRIMARY KEY, -- IDENTITY cho phép tự động tăng
    MaBS CHAR(5) NOT NULL,
    NgayKham DATE NOT NULL,
    MaBenhNhan CHAR(10) NOT NULL,
    TinhTrangKham NVARCHAR(50),
    FOREIGN KEY (MaBS) REFERENCES BacSi(MaBS)
);
GO

-- Bảng 3: LichTruc
CREATE TABLE LichTruc (
    MaTruc INT IDENTITY(1,1) PRIMARY KEY,
    MaBS CHAR(5) NOT NULL,
    NgayTruc DATE NOT NULL,
    CaTruc NVARCHAR(20),
    ChuyenKhoaTruc NVARCHAR(50) NOT NULL,
    FOREIGN KEY (MaBS) REFERENCES BacSi(MaBS)
);
GO

----------------------------------------------------------------------
-- Phần 2: CHÈN DỮ LIỆU MẪU (DML)
----------------------------------------------------------------------

-- Chèn dữ liệu vào bảng BacSi
INSERT INTO BacSi (MaBS, HoTen, GioiTinh, DiaChi, ChuyenKhoa) VALUES
('BS001', N'Nguyễn Văn An', N'Nam', N'123 Đường A, Hà Nội', N'Tim mạch'),
('BS002', N'Trần Thị Bình', N'Nữ', N'456 Phố B, TP.HCM', N'Nhi khoa'),
('BS003', N'Lê Minh Cường', N'Nam', N'789 Đường C, Đà Nẵng', N'Da liễu'),
('BS004', N'Phạm Thu Dung', N'Nữ', N'101 Phố D, Hà Nội', N'Tim mạch');
GO

-- Chèn dữ liệu vào bảng LichKham
INSERT INTO LichKham (MaBS, NgayKham, MaBenhNhan, TinhTrangKham) VALUES
('BS001', '2025-10-01', 'BN001001', N'Khám định kỳ'),
('BS001', '2025-10-02', 'BN001002', N'Kiểm tra HA'),
('BS002', '2025-10-01', 'BN002001', N'Sốt'),
('BS002', '2025-10-01', 'BN002002', N'Viêm họng'),
('BS002', '2025-10-03', 'BN002003', N'Tiêm chủng'),
('BS003', '2025-10-05', 'BN003001', N'Mụn trứng cá'),
('BS004', '2025-11-01', 'BN004001', N'Đau ngực');
GO

-- Chèn dữ liệu vào bảng LichTruc
INSERT INTO LichTruc (MaBS, NgayTruc, CaTruc, ChuyenKhoaTruc) VALUES
('BS001', '2025-11-15', N'Sáng', N'Tim mạch'),
('BS002', '2025-11-15', N'Chiều', N'Nhi khoa'),
('BS004', '2025-11-16', N'Tối', N'Tim mạch');
GO

----------------------------------------------------------------------
-- Phần 3: CÁC TRUY VẤN (SELECT)
----------------------------------------------------------------------

-- 1. Danh sách lịch khám của bác sĩ BS002 trong tháng 10/2025
SELECT 
    BS.HoTen, 
    LK.NgayKham, 
    LK.MaBenhNhan, 
    LK.TinhTrangKham
FROM 
    LichKham LK
JOIN 
    BacSi BS ON LK.MaBS = BS.MaBS
WHERE 
    LK.MaBS = 'BS002' 
    AND YEAR(LK.NgayKham) = 2025 
    AND MONTH(LK.NgayKham) = 10
ORDER BY 
    LK.NgayKham;
GO

-- 2. Quản lý lịch trực của chuyên khoa Tim mạch
SELECT 
    BS.HoTen, 
    LT.NgayTruc, 
    LT.CaTruc,
    LT.ChuyenKhoaTruc
FROM 
    LichTruc LT
JOIN 
    BacSi BS ON LT.MaBS = BS.MaBS
WHERE 
    LT.ChuyenKhoaTruc = N'Tim mạch'
ORDER BY 
    LT.NgayTruc, BS.HoTen;
GO

-- 3. Tính tổng số lần khám của từng bác sĩ
SELECT 
    BS.MaBS,
    BS.HoTen, 
    COUNT(LK.MaKham) AS TongSoLanKham
FROM 
    BacSi BS
LEFT JOIN 
    LichKham LK ON BS.MaBS = LK.MaBS
GROUP BY 
    BS.MaBS, 
    BS.HoTen
ORDER BY 
    TongSoLanKham DESC;
GO

-- 4. Danh sách bác sĩ có nhiều bệnh nhân nhất (TOP)
WITH SoLanKham AS (
    SELECT MaBS, COUNT(MaKham) AS TongSoBenhNhan
    FROM LichKham
    GROUP BY MaBS
)
SELECT TOP 1 WITH TIES 
    BS.HoTen, 
    BS.ChuyenKhoa, 
    SLK.TongSoBenhNhan
FROM 
    BacSi BS
JOIN 
    SoLanKham SLK ON BS.MaBS = SLK.MaBS
ORDER BY 
    SLK.TongSoBenhNhan DESC;
GO

-- 5. Danh sách bác sĩ có ít bệnh nhân nhất (BOTTOM)
WITH SoLanKham AS (
    SELECT 
        BS.MaBS, 
        BS.HoTen,
        COUNT(LK.MaKham) AS TongSoBenhNhan
    FROM 
        BacSi BS
    LEFT JOIN
        LichKham LK ON BS.MaBS = LK.MaBS
    GROUP BY 
        BS.MaBS, BS.HoTen
)
SELECT TOP 1 WITH TIES 
    SLK.HoTen, 
    SLK.TongSoBenhNhan
FROM 
    SoLanKham SLK
ORDER BY 
    SLK.TongSoBenhNhan ASC;
GO